using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Modbus.UnitTests")]
[assembly: AssemblyProduct("NModbus")]
[assembly: AssemblyCopyright("Licensed under MIT License.")]
[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
[assembly: Guid("244bb5c5-2aec-437a-b1c3-4b312ace54fc")]
[assembly: AssemblyVersion("1.11.0.0")]
[assembly: AssemblyFileVersion("1.11.0.0")]
