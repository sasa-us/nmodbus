using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Net.Sockets;
using log4net;
using Modbus.IO;
using Unme.Common;
using Unme.Common.NullReferenceExtension;

namespace Modbus.Device
{
	/// <summary>
	/// Modbus TCP slave device.
	/// </summary>
	public class ModbusTcpSlave : ModbusSlave
	{
		private readonly object _mastersLock = new object();
		private readonly object _serverLock = new object();
		private readonly ILog _logger = LogManager.GetLogger(typeof(ModbusTcpSlave));
		private readonly Dictionary<string, ModbusMasterTcpConnection> _masters = new Dictionary<string, ModbusMasterTcpConnection>();
		private TcpListener _server;

		private ModbusTcpSlave(byte unitId, TcpListener tcpListener)
			: base(unitId, new EmptyTransport())
		{
			if (tcpListener == null)
				throw new ArgumentNullException("tcpListener");

			_server = tcpListener;
		}

		/// <summary>
		/// Gets the Modbus TCP Masters connected to this Modbus TCP Slave.
		/// </summary>
		public ReadOnlyCollection<TcpClient> Masters
		{
			get
			{
				lock (_mastersLock)
					return new ReadOnlyCollection<TcpClient>(_masters.Values.Select(mc => mc.TcpClient).ToList());
			}
		}

		/// <summary>
		/// Gets the server.
		/// </summary>
		/// <value>The server.</value>
		/// <remarks>
		/// This property is not thread safe, it should only be consumed within a lock.
		/// </remarks>
		private TcpListener Server
		{
			get
			{
				if (_server == null)
					throw new ObjectDisposedException("Server");

				return _server;
			}
		}

		/// <summary>
		/// Modbus TCP slave factory method.
		/// </summary>
		public static ModbusTcpSlave CreateTcp(byte unitId, TcpListener tcpListener)
		{
			return new ModbusTcpSlave(unitId, tcpListener);
		}

		/// <summary>
		/// Start slave listening for requests.
		/// </summary>
		public override void Listen()
		{
			_logger.Debug("Start Modbus Tcp Server.");

			lock (_serverLock)
			{
				try
				{
					Server.Start();

					// use Socket async API for compact framework compat
					Server.Server.BeginAccept(AcceptCompleted, this);
				}
				catch (ObjectDisposedException)
				{
					// this happens when the server stops
				}
			}
		}

		internal void RemoveMaster(string endPoint)
		{
			lock (_mastersLock)
			{
                if (_masters.ContainsKey(endPoint))
                {
                    ModbusMasterTcpConnection masterTCPConnection = _masters[endPoint];
                    if (masterTCPConnection != null)
                    {
                        masterTCPConnection.ReleaseResources();
                        masterTCPConnection.ModbusMasterTcpConnectionClosed -= (sender, eventArgs) => RemoveMaster(eventArgs.EndPoint);
                    }

                    if (!_masters.Remove(endPoint))
                    {
                        throw new ArgumentException(String.Format(CultureInfo.InvariantCulture, "EndPoint {0} cannot be removed, it does not exist.", endPoint));
                    }                 
                }                
			}			
		}

		internal void AcceptCompleted(IAsyncResult ar)
		{
			ModbusTcpSlave slave = (ModbusTcpSlave) ar.AsyncState;

            try
            {
                // use Socket async API for compact framework compat
                Socket socket = null;
                lock (_serverLock)
                    socket = Server.Server.EndAccept(ar);

                TcpClient client = new TcpClient { Client = socket };
                string endPoint = client.Client.RemoteEndPoint.ToString();

                // During rapid socket open/close testing, occasionally a closed connection did not
                // get removed and released.  This caused an exception when Add() was called below.
                // Was not able to determine the root cause.  Therefore added a call to
                // RemoveMaster before creating the new master to clean up an old instance if one
                // still exists.
                RemoveMaster(endPoint);

                var masterConnection = new ModbusMasterTcpConnection(client, slave);
                lock (_mastersLock)
                {
                    _masters.Add(endPoint, masterConnection);
                }
                masterConnection.ModbusMasterTcpConnectionClosed += (sender, eventArgs) => RemoveMaster(eventArgs.EndPoint);

                _logger.Debug("Accept completed.");

                // Socket might have dropped prior to attaching RemoveMaster event handler.
                // Cover that case here to ensure resources get released.
                // Note: If the RemoveMaster handler already fired, calling RemoveMaster again is safe
                if (!socket.Connected)
                    RemoveMaster(endPoint);

                // throttle the rate of accepting new socket connections 
                // to prevent getting swamped by a stream of socket connections
                System.Threading.Thread.Sleep(100);

                // Accept another client
                // use Socket async API for compact framework compat
                lock (_serverLock)
                    Server.Server.BeginAccept(AcceptCompleted, slave);
            }
            catch (ObjectDisposedException)
            {
                // this happens when the server stops
            }
            catch (Exception e)
            {
            }
		}

		/// <summary>
		/// Releases unmanaged and - optionally - managed resources
		/// </summary>
		/// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
		/// <remarks>Dispose is thread-safe.</remarks>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				// double-check locking
				if (_server != null)
				{
					lock (_serverLock)
					{
						if (_server != null)
						{
							_server.Stop();
							_server = null;
						}
					}
				}
			}
		}
	}
}
