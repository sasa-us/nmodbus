using System;
using System.Collections.Generic;
using System.Globalization;

namespace Modbus.Message
{
	internal class SlaveExceptionResponse : ModbusMessage, IModbusMessage
	{
		private static readonly Dictionary<byte, string> _exceptionMessages = CreateExceptionMessages();		

		public SlaveExceptionResponse()
		{
		}

		public SlaveExceptionResponse(byte slaveAddress, byte functionCode, byte exceptionCode)
			: base(slaveAddress, functionCode)	
		{
			SlaveExceptionCode = exceptionCode;
		}

		public override int MinimumFrameSize
		{
			get { return 3; }
		}

		public byte SlaveExceptionCode
		{
			get { return MessageImpl.ExceptionCode.Value; }
			set { MessageImpl.ExceptionCode = value; }
		}

		/// <summary>
		/// Returns a <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
		/// </summary>
		/// <returns>
		/// A <see cref="T:System.String"></see> that represents the current <see cref="T:System.Object"></see>.
		/// </returns>
		public override string ToString()
		{
			string message = _exceptionMessages.ContainsKey(SlaveExceptionCode) ? _exceptionMessages[SlaveExceptionCode] : "Unknown Exception";

            return message;
		}

		internal static Dictionary<byte, string> CreateExceptionMessages()
		{
			Dictionary<byte, string> messages = new Dictionary<byte, string>(9);

			messages.Add(1,  "Illegal Function");
			messages.Add(2,  "Illegal Data Address");
			messages.Add(3,  "Illegal Data Value");
			messages.Add(4,  "Slave Device Failure");
			messages.Add(5,  "Acknowledge");
			messages.Add(6,  "Slave Device Busy");
			messages.Add(8,  "Memory Parity Error");
			messages.Add(10, "Gateway Path Unavailable");
			messages.Add(11, "Gateway Target Device failed to respond");

			return messages;
		}

		protected override void InitializeUnique(byte[] frame)
		{
			if (FunctionCode <= Modbus.ExceptionOffset)
				throw new FormatException("Slave Exception Response Invalid FunctionCode");

			SlaveExceptionCode = frame[2];
		}
	}
}
